// import { InputType, Field} from "@nestjs/graphql";
// // import { Product } from "src/apis/products/entities/product.entity";

// @InputType()
// export class CreateProductImageInput{
//   // @Field(()=>String)
//   // id: string

//   @Field(()=>String)
//   url: string

//   @Field(()=> String)
//   product:string
// }

